# Literate Micro

Support for reading `.lit` files from [zyedidia/Literate](https://github.com/zyedidia/Literate).

This plugin will automatically detect the filetype and highlight the correct language inside the code blocks.
