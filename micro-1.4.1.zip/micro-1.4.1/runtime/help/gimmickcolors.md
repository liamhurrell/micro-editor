# Gimmick colors

We have included a few colorschemes that are for fun:

* funky-cactus: I don't know why I made this. (Written by CaptainMcClellan)
* gameboy-tc: Colorscheme based on the olive green original Gameboy!
* nes-tc: A colorscheme and syntax highlighting using only colors in the 
  Nintendo Entertainment System color palette.
* symbian-tc: Colorscheme based on SymbOS's GUI.
* matrix: Pretend it's 1981 with a colorscheme based on a monochrome
  IBM 5151. (Does not include the ghosting and trailing)

Check the plugin repo periodically for gimmick-color extension packs and genuine
additional themes.